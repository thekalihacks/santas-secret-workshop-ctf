from flask import Flask, request, abort

app = Flask(__name__)

FLAG = "flag{toys_factory_secret}"

@app.route('/')
def home():
    return "Welcome to the Toy Factory admin panel. Use /admin?file=<filename> to read config files."

@app.route('/admin')
def admin_read():
    filename = request.args.get('file', '')
    try:
        with open(filename, 'r') as f:
            return f"<pre>{f.read()}</pre>"
    except Exception as e:
        abort(404, "File not found or access denied.")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)