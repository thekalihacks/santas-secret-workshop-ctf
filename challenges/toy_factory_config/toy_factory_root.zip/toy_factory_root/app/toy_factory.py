from flask import Flask, request, abort
import os

app = Flask(__name__)

@app.route('/')
def home():
    return "Welcome to the Toy Factory admin panel. Use /admin?file=<filename> to read config files."

@app.route('/admin')
def admin_read():
    filename = request.args.get('file', '')
    try:
        with open(filename, 'r') as f:
            content = f.read()
        return f"<pre>{content}</pre>"
    except Exception as e:
        abort(404, "File not found or access denied.")

if __name__ == "__main__":
    # run from directory of this script
    app.run(host="127.0.0.1", port=8080)
