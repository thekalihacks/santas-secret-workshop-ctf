from flask import Flask, request, render_template_string

app = Flask(__name__)

# Very simple “database” of users
users = {
    "admin": "password123"
}

flag = "flag{reindeer_portal}"

login_page = """
<html>
  <body>
    <h1>Reindeer Portal Login</h1>
    <form method="post">
      Username: <input name="username"><br>
      Password: <input name="password"><br>
      <input type="submit" value="Login">
    </form>
    {% if message %}
      <p>{{ message }}</p>
    {% endif %}
  </body>
</html>
"""

@app.route("/", methods=["GET", "POST"])
def login():
    message = ""
    if request.method == "POST":
        user = request.form.get("username", "")
        pw = request.form.get("password", "")
        # VERY insecure “SQL” style logic simulation
        if "'" in user or "OR" in user.upper():
            # Injection success: grant access
            message = f"Welcome! Here is your magic key page: {flag}"
        elif user in users and users[user] == pw:
            message = f"Welcome {user}! Here is your magic key page: {flag}"
        else:
            message = "Invalid login."
    return render_template_string(login_page, message=message)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5005)
